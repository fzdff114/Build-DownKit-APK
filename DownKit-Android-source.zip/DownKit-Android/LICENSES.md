# Third-party notices

DownKit bundles or builds the following third-party components. Keep these notices with redistributed builds.

| Component | Version | License / notice | Source |
|---|---|---|---|
| yt-dlp | 2026.10.26 | Unlicense (public domain dedication) | https://github.com/yt-dlp/yt-dlp |
| yt-dlp-ejs | 0.8.0 | Unlicense; includes MIT/ISC-licensed components as documented upstream | https://github.com/yt-dlp/ejs |
| QuickJS-NG | 0.12.0 | MIT | https://github.com/quickjs-ng/quickjs |
| FFmpegKit maintained Android package | 8.1.9 | LGPL-3.0 for the `full` (non-GPL) artifact | https://github.com/ffmpegkit-maintained/ffmpeg |
| Chaquopy Python SDK | 17.2.0 | See the SDK's own terms | https://www.chaquo.com/chaquopy/ |
| Requests | 2.34.2 | Apache-2.0 | https://github.com/psf/requests |
| urllib3 | 2.8.0 | MIT | https://github.com/urllib3/urllib3 |
| websockets | 17.3 | BSD-3-Clause | https://github.com/python-websockets/websockets |
| certifi | 2026.10.23 | MPL-2.0 | https://github.com/certifi/python-certifi |
| Brotli | 1.1.0 | MIT | https://github.com/google/brotli |
| PyCryptodomeX | 3.21.0 | BSD-2-Clause / Public Domain | https://github.com/Legrandin/pycryptodome |
| Picasso | 2.8 | Apache-2.0 | https://github.com/square/picasso |
| AndroidX / Material Components | See Gradle dependency versions | Apache-2.0 | https://developer.android.com/ |

The original yt-dlp license text is included in `LICENSE-ytdlp.txt`. The FFmpegKit artifact used here is the LGPL `full` artifact, not a `full-gpl` artifact. Review each upstream license and the package's distribution requirements before publishing an APK.
