package com.downkit.android

import android.app.Application
import android.util.Log
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

class DownKitApp : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        } catch (e: Exception) {
            Log.e("DownKit", "Python runtime startup failed", e)
        }
    }
}
