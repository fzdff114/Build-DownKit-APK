package com.downkit.android

import android.content.Context
import java.util.concurrent.atomic.AtomicReference

object DownloadEvents {
    private val app = AtomicReference<Context?>(null)

    fun initialize(context: Context) { app.set(context.applicationContext) }

    @JvmStatic
    fun onProgress(taskId: String, stage: String, percent: Double, speed: String, eta: String) {
        val context = app.get() ?: return
        val label = when (stage) {
            "finished" -> "正在合并/整理"
            "downloading" -> "下载中"
            "error" -> "下载失败"
            else -> "处理中"
        }
        DownloadTaskStore.markProgress(context, taskId, percent.toInt(), speed, eta, label)
        DownloadService.refreshNotification(context, taskId)
    }

    @JvmStatic
    fun isCancelled(taskId: String): Boolean {
        val context = app.get() ?: return false
        return DownloadTaskStore.isCancelled(context, taskId)
    }

    @JvmStatic
    fun onMessage(taskId: String, message: String) {
        val context = app.get() ?: return
        DownloadTaskStore.update(context, taskId) { it.copy(error = message.take(600)) }
    }
}
