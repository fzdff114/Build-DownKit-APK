package com.downkit.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.chaquo.python.Python
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class DownloadService : Service() {
    private val worker = Executors.newSingleThreadExecutor()
    private val running = AtomicBoolean(false)
    @Volatile private var latestStartId = 0

    override fun onCreate() {
        super.onCreate()
        createChannel()
        DownloadEvents.initialize(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        latestStartId = startId
        if (running.compareAndSet(false, true)) {
            val notification = buildNotification("准备下载", 0)
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            worker.execute { drainQueue() }
        }
        return START_NOT_STICKY
    }

    private fun drainQueue() {
        try {
            while (true) {
                val task = DownloadTaskStore.nextPending(this) ?: break
                if (DownloadTaskStore.isCancelled(this, task.id)) continue
                DownloadTaskStore.update(this, task.id) { it.copy(status = "下载中", progress = 0, error = "") }
                updateNotification(task.id)
                val taskDir = File(filesDir, "downloads/${task.id}").apply { mkdirs() }
                var keepPartialFiles = true
                try {
                    val cookies = DownloadTaskStore.cookiesPath(this)
                    val proxy = DownloadTaskStore.proxy(this)
                    val playlist = DownloadTaskStore.playlist(this)
                    val resultText = Python.getInstance().getModule("bridge").callAttr(
                        "download_video", task.url, task.formatSelector, taskDir.absolutePath,
                        task.id, cookies, proxy, playlist
                    ).toString()
                    val result = JSONObject(resultText)
                    if (result.optBoolean("cancelled") || DownloadTaskStore.isCancelled(this, task.id)) {
                        DownloadTaskStore.update(this, task.id) { it.copy(status = "已取消", progress = 0) }
                    } else if (result.has("error")) {
                        throw IllegalStateException(result.optString("error"))
                    } else {
                        val savedUris = mutableListOf<String>()
                        val files = result.optJSONArray("files")
                        if (files == null || files.length() == 0) throw IllegalStateException("网站没有返回可保存的媒体文件")
                        for (i in 0 until files.length()) {
                            if (DownloadTaskStore.isCancelled(this, task.id)) break
                            val item = files.getJSONObject(i)
                            val source = File(item.getString("path"))
                            val uri = MediaSaver.save(this, source, DownloadTaskStore.folderUri(this))
                            savedUris += uri.toString()
                            source.delete()
                        }
                        if (DownloadTaskStore.isCancelled(this, task.id)) {
                            keepPartialFiles = false
                            DownloadTaskStore.update(this, task.id) { it.copy(status = "已取消", savedUri = savedUris.firstOrNull() ?: "", savedCount = savedUris.size) }
                        } else {
                            keepPartialFiles = false
                            DownloadTaskStore.update(this, task.id) {
                                it.copy(status = "已完成", progress = 100, speed = "", eta = "", savedUri = savedUris.firstOrNull() ?: "", savedCount = savedUris.size)
                            }
                        }
                    }
                } catch (e: Exception) {
                    val cancelled = DownloadTaskStore.isCancelled(this, task.id)
                    if (cancelled) keepPartialFiles = false
                    DownloadTaskStore.update(this, task.id) {
                        it.copy(status = if (cancelled) "已取消" else "失败", error = if (cancelled) "" else (e.message ?: "下载失败").take(600))
                    }
                } finally {
                    if (!keepPartialFiles) taskDir.deleteRecursively()
                }
                updateNotification(task.id)
            }
        } finally {
            running.set(false)
            if (DownloadTaskStore.nextPending(this) != null && running.compareAndSet(false, true)) {
                worker.execute { drainQueue() }
                return
            }
            if (!running.get()) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelfResult(latestStartId)
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "下载任务", NotificationManager.IMPORTANCE_LOW).apply {
                description = "显示视频下载进度"
                setShowBadge(true)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, progress: Int): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("DownKit · $title")
            .setContentText(if (progress in 1..99) "已完成 $progress%" else "任务正在处理")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, progress.coerceIn(0, 100), progress <= 0)
            .build()
    }

    private fun updateNotification(taskId: String) {
        val task = DownloadTaskStore.get(this, taskId) ?: return
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(task.title, task.progress))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "downkit_downloads"
        private const val NOTIFICATION_ID = 8173

        fun start(context: Context) {
            val intent = Intent(context, DownloadService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun refreshNotification(context: Context, taskId: String) {
            val task = DownloadTaskStore.get(context, taskId) ?: return
            val manager = context.getSystemService(NotificationManager::class.java)
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_download)
                .setContentTitle("DownKit · ${task.title}")
                .setContentText("${task.progress}%  ${task.speed}  ${if (task.eta.isNotBlank()) "剩余 ${task.eta}" else ""}")
                .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
                .setProgress(100, task.progress.coerceIn(0, 100), task.progress <= 0).build()
            manager.notify(NOTIFICATION_ID, notification)
        }
    }
}
