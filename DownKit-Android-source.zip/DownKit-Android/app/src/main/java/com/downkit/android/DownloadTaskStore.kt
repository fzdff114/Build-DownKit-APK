package com.downkit.android

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.io.File


data class DownloadTask(
    val id: String,
    val url: String,
    val title: String,
    val formatSelector: String,
    val formatLabel: String,
    val status: String = "等待中",
    val progress: Int = 0,
    val speed: String = "",
    val eta: String = "",
    val error: String = "",
    val savedUri: String = "",
    val savedCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val cancelRequested: Boolean = false
)

object DownloadTaskStore {
    private const val FILE = "downkit_tasks"
    private const val KEY = "tasks"

    @Synchronized
    private fun read(context: Context): MutableList<DownloadTask> {
        val raw = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val array = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        val result = mutableListOf<DownloadTask>()
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            result += DownloadTask(
                id = o.optString("id"), url = o.optString("url"), title = o.optString("title"),
                formatSelector = o.optString("formatSelector", "bestvideo+bestaudio/best"),
                formatLabel = o.optString("formatLabel", "自动最佳画质"),
                status = o.optString("status", "等待中"), progress = o.optInt("progress", 0),
                speed = o.optString("speed"), eta = o.optString("eta"), error = o.optString("error"),
                savedUri = o.optString("savedUri"), savedCount = o.optInt("savedCount"),
                createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                cancelRequested = o.optBoolean("cancelRequested", false)
            )
        }
        return result
    }

    @Synchronized
    private fun write(context: Context, tasks: List<DownloadTask>) {
        val array = JSONArray()
        tasks.forEach { t ->
            array.put(JSONObject().apply {
                put("id", t.id); put("url", t.url); put("title", t.title)
                put("formatSelector", t.formatSelector); put("formatLabel", t.formatLabel)
                put("status", t.status); put("progress", t.progress); put("speed", t.speed)
                put("eta", t.eta); put("error", t.error); put("savedUri", t.savedUri)
                put("savedCount", t.savedCount); put("createdAt", t.createdAt)
                put("cancelRequested", t.cancelRequested)
            })
        }
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }

    @Synchronized
    fun all(context: Context): List<DownloadTask> = read(context).sortedByDescending { it.createdAt }
    @Synchronized
    fun get(context: Context, id: String): DownloadTask? = read(context).firstOrNull { it.id == id }

    @Synchronized
    fun add(context: Context, url: String, title: String, formatSelector: String, formatLabel: String): DownloadTask {
        val task = DownloadTask(UUID.randomUUID().toString(), url, title, formatSelector, formatLabel)
        val tasks = read(context)
        tasks.add(0, task)
        write(context, tasks.take(100))
        return task
    }

    @Synchronized
    fun update(context: Context, id: String, change: (DownloadTask) -> DownloadTask) {
        val tasks = read(context)
        val index = tasks.indexOfFirst { it.id == id }
        if (index >= 0) {
            tasks[index] = change(tasks[index])
            write(context, tasks)
        }
    }

    @Synchronized
    fun nextPending(context: Context): DownloadTask? = read(context).firstOrNull { it.status == "等待中" }

    @Synchronized
    fun markProgress(context: Context, id: String, progress: Int, speed: String, eta: String, status: String) {
        update(context, id) { it.copy(progress = progress.coerceIn(0, 100), speed = speed, eta = eta, status = status) }
    }

    @Synchronized
    fun cancel(context: Context, id: String) {
        update(context, id) { it.copy(cancelRequested = true, status = if (it.status == "等待中") "已取消" else it.status) }
    }

    @Synchronized
    fun retry(context: Context, id: String) {
        update(context, id) {
            it.copy(status = "等待中", error = "", speed = "", eta = "", cancelRequested = false)
        }
    }

    @Synchronized
    fun recoverInterrupted(context: Context) {
        val tasks = read(context)
        var changed = false
        for (index in tasks.indices) {
            val task = tasks[index]
            if (task.status == "下载中" || task.status == "正在合并/整理" || task.status == "处理中") {
                tasks[index] = task.copy(status = "等待中", speed = "", eta = "", error = "应用上次退出时任务中断，已重新加入队列", cancelRequested = false)
                changed = true
            }
        }
        if (changed) write(context, tasks)
    }

    @Synchronized
    fun hasPending(context: Context): Boolean = nextPending(context) != null

    @Synchronized
    fun isCancelled(context: Context, id: String): Boolean = get(context, id)?.cancelRequested == true

    @Synchronized
    fun clearFinished(context: Context) {
        val all = read(context)
        val removable = all.filter { it.status == "已完成" || it.status == "已取消" || it.status == "失败" }
        removable.forEach { File(context.filesDir, "downloads/${it.id}").deleteRecursively() }
        write(context, all.filterNot { it in removable })
    }

    @Synchronized
    fun setSettings(context: Context, proxy: String, playlist: Boolean, folderUri: String) {
        context.getSharedPreferences("downkit_settings", Context.MODE_PRIVATE).edit()
            .putString("proxy", proxy.trim()).putBoolean("playlist", playlist).putString("folderUri", folderUri).apply()
    }

    @Synchronized
    fun proxy(context: Context): String = context.getSharedPreferences("downkit_settings", Context.MODE_PRIVATE).getString("proxy", "") ?: ""
    @Synchronized
    fun playlist(context: Context): Boolean = context.getSharedPreferences("downkit_settings", Context.MODE_PRIVATE).getBoolean("playlist", false)
    @Synchronized
    fun folderUri(context: Context): String = context.getSharedPreferences("downkit_settings", Context.MODE_PRIVATE).getString("folderUri", "") ?: ""
    @Synchronized
    fun cookiesPath(context: Context): String = context.getFileStreamPath("cookies.txt").takeIf { it.exists() }?.absolutePath ?: ""
}
