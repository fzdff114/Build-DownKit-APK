package com.downkit.android

import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode

/** Java-callable FFmpeg entry point used by yt-dlp's custom merger postprocessor. */
object FfmpegBridge {
    @JvmStatic
    fun execute(arguments: Array<String>) {
        val session = FFmpegKit.executeWithArguments(arguments)
        val code = session.returnCode
        if (!ReturnCode.isSuccess(code)) {
            val detail = session.failStackTrace ?: session.allLogsAsString ?: "未知 FFmpeg 错误"
            throw IllegalStateException("音视频合并失败：$detail")
        }
    }
}
