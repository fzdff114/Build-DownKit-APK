package com.downkit.android

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import androidx.core.view.updateLayoutParams
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.documentfile.provider.DocumentFile
import com.chaquo.python.Python
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.squareup.picasso.Picasso
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

private data class FormatChoice(val label: String, val selector: String, val kind: String = "video")

class MainActivity : AppCompatActivity() {
    private val io = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var page: FrameLayout
    private lateinit var bottom: BottomNavigationView
    private var currentTab = 1
    private var parsedInfo: JSONObject? = null
    private var formats: List<FormatChoice> = emptyList()
    private var urlField: TextInputEditText? = null
    private var formatSpinner: Spinner? = null
    private var infoCard: MaterialCardView? = null
    private var parseButton: MaterialButton? = null
    private var downloadButton: MaterialButton? = null
    private var proxyField: TextInputEditText? = null
    private var playlistSwitch: MaterialSwitch? = null
    private var runtimeStatus: TextView? = null
    private var taskScrollY = 0

    private val cookiePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importCookies(uri)
    }
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                DownloadTaskStore.setSettings(this, DownloadTaskStore.proxy(this), DownloadTaskStore.playlist(this), uri.toString())
                toast("已设置保存目录")
            }.onFailure { toast("无法保存目录权限：${it.message}") }
            renderSettings()
        }
    }

    private val refreshLoop = object : Runnable {
        override fun run() {
            if (currentTab == 2 && ::page.isInitialized) renderTasks()
            handler.postDelayed(this, 1100)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.WHITE
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        buildShell()
        DownloadTaskStore.recoverInterrupted(this)
        if (DownloadTaskStore.hasPending(this)) DownloadService.start(this)
        handleIncomingIntent(intent)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 701)
        }
        if (!Python.isStarted()) {
            toast("Python 运行环境尚未就绪，请重新打开应用")
        } else {
            io.execute {
                val status = runCatching { Python.getInstance().getModule("bridge").callAttr("configure", QuickJsInstaller.install(this) ?: "").toString() }
                    .getOrNull()
                runOnUiThread {
                    runtimeStatus?.text = status?.let {
                        val j = JSONObject(it)
                        "yt-dlp ${j.optString("yt_dlp")} · EJS ${if (j.optBoolean("ejs")) "已就绪" else "未加载"} · QuickJS ${if (j.optBoolean("quickjs")) "已就绪" else "未就绪"}"
                    } ?: "运行环境初始化失败"
                }
            }
        }
        handler.post(refreshLoop)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        val shared = intent?.getStringExtra(Intent.EXTRA_TEXT)
            ?: if (intent?.action == Intent.ACTION_VIEW) intent.dataString else null
        if (!shared.isNullOrBlank() && ::page.isInitialized) {
            currentTab = 1
            bottom.selectedItemId = 1
            renderHome()
            urlField?.setText(shared.trim())
        }
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 248, 252))
        }
        val toolbar = com.google.android.material.appbar.MaterialToolbar(this).apply {
            title = "DownKit"
            setTitleTextColor(Color.rgb(23, 32, 51))
            setBackgroundColor(Color.WHITE)
            elevation = dp(1).toFloat()
            setSubtitle("简洁 · 稳定 · 多站点")
        }
        root.addView(toolbar, LinearLayout.LayoutParams(-1, dp(58)))
        page = FrameLayout(this)
        root.addView(page, LinearLayout.LayoutParams(-1, 0, 1f))
        bottom = BottomNavigationView(this).apply {
            setBackgroundColor(Color.WHITE)
            menu.add(0, 1, 0, "下载").setIcon(android.R.drawable.ic_menu_view)
            menu.add(0, 2, 1, "任务").setIcon(android.R.drawable.ic_menu_recent_history)
            menu.add(0, 3, 2, "设置").setIcon(android.R.drawable.ic_menu_preferences)
            selectedItemId = 1
            setOnItemSelectedListener { item ->
                currentTab = item.itemId
                when (item.itemId) {
                    1 -> renderHome()
                    2 -> renderTasks()
                    3 -> renderSettings()
                }
                true
            }
        }
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(64)))
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val topInset = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            val bottomInset = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            toolbar.updateLayoutParams<LinearLayout.LayoutParams> { height = dp(58) + topInset }
            toolbar.setPadding(toolbar.paddingLeft, topInset, toolbar.paddingRight, toolbar.paddingBottom)
            bottom.updateLayoutParams<LinearLayout.LayoutParams> { height = dp(64) + bottomInset }
            bottom.setPadding(bottom.paddingLeft, bottom.paddingTop, bottom.paddingRight, bottomInset)
            insets
        }
        renderHome()
    }

    private fun renderHome() {
        currentTab = 1
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(20))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(column) }
        column.addView(text("把链接变成文件", 25, true, Color.rgb(23, 32, 51)), margin(bottom = 4))
        column.addView(text("粘贴公开视频链接，解析格式后开始下载。", 14, false, Color.rgb(102, 112, 133)), margin(bottom = 16))

        val inputCard = card()
        val inputColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16)) }
        val linkLayout = TextInputLayout(this).apply {
            hint = "视频 / 音频 / 播放列表链接"
            boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
            endIconMode = TextInputLayout.END_ICON_CLEAR_TEXT
        }
        urlField = TextInputEditText(this).apply {
            setSingleLine(true)
            textSize = 15f
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            hint = "https://..."
        }
        linkLayout.addView(urlField)
        inputColumn.addView(linkLayout, margin(bottom = 12))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val paste = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "粘贴链接"
            icon = ContextCompat.getDrawable(this@MainActivity, android.R.drawable.ic_menu_edit)
            setOnClickListener { pasteLink() }
        }
        parseButton = MaterialButton(this).apply {
            text = "解析链接"
            setOnClickListener { parseLink() }
        }
        actions.addView(paste, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(8) })
        actions.addView(parseButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        inputColumn.addView(actions)
        inputCard.addView(inputColumn)
        column.addView(inputCard, margin(bottom = 14))

        infoCard = card().apply { visibility = View.GONE }
        val infoColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14)) }
        val mediaRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val cover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(232, 237, 246))
        }
        mediaRow.addView(cover, LinearLayout.LayoutParams(dp(112), dp(76)).apply { marginEnd = dp(12) })
        val metaCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        val titleView = text("", 16, true, Color.rgb(23, 32, 51))
        titleView.maxLines = 2
        val detailView = text("", 12, false, Color.rgb(102, 112, 133))
        metaCol.addView(titleView, margin(bottom = 5))
        metaCol.addView(detailView)
        mediaRow.addView(metaCol)
        infoColumn.addView(mediaRow, margin(bottom = 14))
        infoColumn.addView(text("下载格式", 14, true, Color.rgb(23, 32, 51)), margin(bottom = 7))
        formatSpinner = Spinner(this)
        infoColumn.addView(formatSpinner, margin(bottom = 12))
        downloadButton = MaterialButton(this).apply {
            text = "开始下载"
            setIconResource(android.R.drawable.stat_sys_download)
            isEnabled = false
            setOnClickListener { startDownload() }
        }
        infoColumn.addView(downloadButton, LinearLayout.LayoutParams(-1, dp(50)))
        infoCard?.addView(infoColumn)
        column.addView(infoCard!!, margin(bottom = 12))
        column.addView(text("网站支持", 17, true, Color.rgb(23, 32, 51)), margin(bottom = 5))
        column.addView(text("解析能力由 yt-dlp 提供，覆盖大量视频网站和媒体站点。少数网站会因登录、地区、验证码、反爬或站点改版而受限。", 13, false, Color.rgb(102, 112, 133)), margin(bottom = 14))
        column.addView(text("提示：请仅下载你有权保存的内容，并遵守网站条款及当地法律。", 12, false, Color.rgb(122, 132, 150)))

        infoCard?.tag = HomeViews(cover, titleView, detailView)
        page.removeAllViews()
        page.addView(scroll, FrameLayout.LayoutParams(-1, -1))
    }

    private data class HomeViews(val cover: ImageView, val title: TextView, val details: TextView)

    private fun parseLink() {
        val url = urlField?.text?.toString()?.trim().orEmpty()
        if (!(url.startsWith("https://") || url.startsWith("http://"))) {
            toast("请先粘贴完整的视频链接")
            return
        }
        parsedInfo = null
        downloadButton?.isEnabled = false
        parseButton?.isEnabled = false
        parseButton?.text = "解析中…"
        infoCard?.visibility = View.VISIBLE
        (infoCard?.tag as? HomeViews)?.let {
            it.title.text = "正在解析链接…"
            it.details.text = "正在读取网站媒体信息和可用格式"
        }
        io.execute {
            val raw = runCatching {
                Python.getInstance().getModule("bridge").callAttr("inspect_url", url).toString()
            }.getOrElse { JSONObject().put("ok", false).put("error", it.message ?: "解析失败").toString() }
            runOnUiThread {
                parseButton?.isEnabled = true
                parseButton?.text = "解析链接"
                val result = runCatching { JSONObject(raw) }.getOrElse { JSONObject().put("ok", false).put("error", "解析结果格式错误") }
                if (!result.optBoolean("ok")) {
                    infoCard?.visibility = View.GONE
                    toast("解析失败：${result.optString("error", "未知错误").take(120)}")
                    return@runOnUiThread
                }
                parsedInfo = result
                val views = infoCard?.tag as? HomeViews
                views?.title?.text = result.optString("title", "未命名媒体")
                val details = listOf(result.optString("uploader"), result.optString("duration"), result.optString("extractor"))
                    .filter { it.isNotBlank() }.joinToString(" · ")
                views?.details?.text = details.ifBlank { "媒体信息已读取" }
                val thumb = result.optString("thumbnail")
                if (thumb.startsWith("http")) views?.cover?.let { Picasso.get().load(thumb).fit().centerCrop().into(it) }
                else views?.cover?.setImageDrawable(null)

                formats = mutableListOf(
                    FormatChoice("自动最佳画质（视频 + 音频）", "bestvideo+bestaudio/best", "video"),
                    FormatChoice("最佳单文件（兼容优先）", "best", "video"),
                    FormatChoice("仅音频（最佳可用音质）", "bestaudio/best", "audio")
                ) + (0 until result.optJSONArray("formats")?.length().orZero()).mapNotNull { index ->
                    val o = result.optJSONArray("formats")?.optJSONObject(index) ?: return@mapNotNull null
                    FormatChoice(o.optString("label"), o.optString("selector"), o.optString("kind", "video"))
                }
                val labels = formats.map { it.label }
                formatSpinner?.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
                formatSpinner?.setSelection(0)
                downloadButton?.isEnabled = true
                infoCard?.visibility = View.VISIBLE
                if (result.optBoolean("is_playlist")) toast("已识别播放列表；是否下载整个列表可在设置中开启")
            }
        }
    }

    private fun startDownload() {
        val info = parsedInfo ?: return toast("请先解析链接")
        val choice = formats.getOrNull(formatSpinner?.selectedItemPosition ?: 0) ?: formats.firstOrNull() ?: return
        val task = DownloadTaskStore.add(
            this,
            urlField?.text?.toString()?.trim().orEmpty(),
            info.optString("title", "媒体下载"),
            choice.selector,
            choice.label
        )
        DownloadService.start(this)
        bottom.selectedItemId = 2
        currentTab = 2
        renderTasks()
        toast("已加入下载队列")
    }

    private fun renderTasks() {
        currentTab = 2
        val previousScrollY = (page.getChildAt(0) as? ScrollView)?.scrollY ?: taskScrollY
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(column)
            setOnScrollChangeListener { _, _, y, _, _ -> taskScrollY = y }
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(text("下载任务", 23, true, Color.rgb(23, 32, 51)), LinearLayout.LayoutParams(0, -2, 1f))
        val clear = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "清除已结束"
            setOnClickListener { DownloadTaskStore.clearFinished(this@MainActivity); taskScrollY = 0; renderTasks() }
        }
        header.addView(clear)
        column.addView(header, margin(bottom = 14))
        val tasks = DownloadTaskStore.all(this)
        if (tasks.isEmpty()) {
            val empty = card()
            val emptyCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20)) }
            emptyCol.addView(text("还没有下载任务", 17, true, Color.rgb(23, 32, 51)), margin(bottom = 7))
            emptyCol.addView(text("解析链接后，点击“开始下载”即可在这里查看进度。", 13, false, Color.rgb(102, 112, 133)))
            empty.addView(emptyCol)
            column.addView(empty)
        }
        tasks.forEach { task ->
            val c = card()
            val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14)) }
            body.addView(text(task.title, 15, true, Color.rgb(23, 32, 51)).apply { maxLines = 2 }, margin(bottom = 5))
            body.addView(text("${task.status} · ${task.formatLabel}", 12, false, Color.rgb(102, 112, 133)), margin(bottom = 8))
            if (task.status == "下载中" || task.status == "正在合并/整理") {
                val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 100; this.progress = task.progress
                    progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(36, 107, 253))
                }
                body.addView(progress, LinearLayout.LayoutParams(-1, dp(7)).apply { bottomMargin = dp(7) })
                body.addView(text("${task.progress}%   ${task.speed}   ${if (task.eta.isNotBlank()) "剩余 ${task.eta}" else ""}", 12, false, Color.rgb(102, 112, 133)), margin(bottom = 8))
            }
            if (task.error.isNotBlank() && task.status == "失败") {
                body.addView(text(task.error, 12, false, Color.rgb(190, 55, 55)), margin(bottom = 8))
            }
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
            if (task.status == "下载中" || task.status == "正在合并/整理" || task.status == "等待中") {
                buttons.addView(MaterialButton(this@MainActivity, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                    text = "取消"
                    setOnClickListener { DownloadTaskStore.cancel(this@MainActivity, task.id); renderTasks() }
                })
            }
            if (task.status == "已完成" && task.savedUri.isNotBlank()) {
                buttons.addView(MaterialButton(this@MainActivity).apply {
                    text = "分享文件"
                    setOnClickListener {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = contentResolver.getType(Uri.parse(task.savedUri)) ?: "video/*"
                            putExtra(Intent.EXTRA_STREAM, Uri.parse(task.savedUri))
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(send, "分享下载文件"))
                    }
                })
            }
            if (task.status == "失败" || task.status == "已取消") {
                buttons.addView(MaterialButton(this@MainActivity, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                    text = "重新加入"
                    setOnClickListener {
                        DownloadTaskStore.retry(this@MainActivity, task.id)
                        DownloadService.start(this@MainActivity)
                        renderTasks()
                    }
                })
            }
            if (task.savedCount > 0) body.addView(text("已保存 ${task.savedCount} 个文件 · Downloads/DownKit", 12, false, Color.rgb(32, 132, 91)))
            if (buttons.childCount > 0) body.addView(buttons)
            c.addView(body)
            column.addView(c, margin(bottom = 10))
        }
        page.removeAllViews()
        page.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        scroll.post { scroll.scrollTo(0, previousScrollY.coerceAtLeast(0)) }
    }

    private fun renderSettings() {
        currentTab = 3
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(22))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(column) }
        column.addView(text("设置", 24, true, Color.rgb(23, 32, 51)), margin(bottom = 14))

        val networkCard = card()
        val network = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16)) }
        network.addView(text("网络", 16, true, Color.rgb(23, 32, 51)), margin(bottom = 8))
        val proxyLayout = TextInputLayout(this).apply {
            hint = "代理地址（可选）"
            boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
        }
        proxyField = TextInputEditText(this).apply {
            setSingleLine(true)
            textSize = 14f
            hint = "http://127.0.0.1:7890"
            setText(DownloadTaskStore.proxy(this@MainActivity))
        }
        proxyLayout.addView(proxyField)
        network.addView(proxyLayout, margin(bottom = 9))
        playlistSwitch = MaterialSwitch(this).apply {
            text = "下载整个播放列表"
            isChecked = DownloadTaskStore.playlist(this@MainActivity)
        }
        network.addView(playlistSwitch)
        val saveSettings = MaterialButton(this).apply {
            text = "保存网络设置"
            setOnClickListener {
                DownloadTaskStore.setSettings(this@MainActivity, proxyField?.text?.toString().orEmpty(), playlistSwitch?.isChecked == true, DownloadTaskStore.folderUri(this@MainActivity))
                toast("设置已保存")
            }
        }
        network.addView(saveSettings, margin(top = 8))
        networkCard.addView(network)
        column.addView(networkCard, margin(bottom = 12))

        val storageCard = card()
        val storage = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16)) }
        storage.addView(text("保存位置", 16, true, Color.rgb(23, 32, 51)), margin(bottom = 5))
        val folder = DownloadTaskStore.folderUri(this)
        storage.addView(text(if (folder.isBlank()) "默认：系统下载目录 / DownKit" else "已选择自定义目录", 13, false, Color.rgb(102, 112, 133)), margin(bottom = 9))
        storage.addView(MaterialButton(this).apply {
            text = "选择保存目录"
            setOnClickListener { folderPicker.launch(null) }
        })
        if (folder.isNotBlank()) {
            storage.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "恢复默认目录"
                setOnClickListener {
                    DownloadTaskStore.setSettings(this@MainActivity, DownloadTaskStore.proxy(this@MainActivity), DownloadTaskStore.playlist(this@MainActivity), "")
                    renderSettings()
                }
            }, margin(top = 5))
        }
        storageCard.addView(storage)
        column.addView(storageCard, margin(bottom = 12))

        val cookieCard = card()
        val cookies = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16)) }
        cookies.addView(text("登录 / Cookie", 16, true, Color.rgb(23, 32, 51)), margin(bottom = 5))
        cookies.addView(text(if (DownloadTaskStore.cookiesPath(this).isNotBlank()) "已导入 cookies.txt（仅保存在本机应用私有目录）" else "需要登录的网站可导入 Netscape 格式 cookies.txt。", 13, false, Color.rgb(102, 112, 133)), margin(bottom = 8))
        cookies.addView(MaterialButton(this).apply {
            text = "导入 cookies.txt"
            setOnClickListener { cookiePicker.launch(arrayOf("text/*", "application/octet-stream")) }
        })
        if (DownloadTaskStore.cookiesPath(this).isNotBlank()) {
            cookies.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "删除本机 Cookie"
                setOnClickListener { getFileStreamPath("cookies.txt").delete(); renderSettings(); toast("已删除") }
            }, margin(top = 5))
        }
        cookieCard.addView(cookies)
        column.addView(cookieCard, margin(bottom = 12))

        column.addView(text("运行组件", 16, true, Color.rgb(23, 32, 51)), margin(bottom = 5))
        runtimeStatus = text("检查中…", 12, false, Color.rgb(102, 112, 133))
        column.addView(runtimeStatus!!)
        column.addView(text("核心解析器：yt-dlp 2026.10.26。网站是否可用取决于目标网站当前规则、网络和登录状态。", 12, false, Color.rgb(122, 132, 150)), margin(top = 8))

        page.removeAllViews()
        page.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        if (Python.isStarted()) {
            io.execute {
                val raw = runCatching { Python.getInstance().getModule("bridge").callAttr("configure", QuickJsInstaller.install(this) ?: "").toString() }.getOrNull()
                runOnUiThread {
                    runtimeStatus?.text = raw?.let {
                        val obj = JSONObject(it)
                        "yt-dlp ${obj.optString("yt_dlp")} · EJS ${if (obj.optBoolean("ejs")) "已就绪" else "未安装"} · QuickJS ${if (obj.optBoolean("quickjs")) "已就绪" else "未构建"} · FFmpegKit 已内置"
                    } ?: "Python 运行环境不可用"
                }
            }
        }
    }

    private fun importCookies(uri: Uri) {
        io.execute {
            val result = runCatching {
                val content = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw IllegalStateException("无法读取所选文件")
                require(content.contains("# Netscape HTTP Cookie File") || content.contains("# HTTP Cookie File") || content.contains(".youtube.com") || content.contains("\tTRUE\t")) {
                    "文件看起来不是 Netscape 格式 cookies.txt"
                }
                openFileOutput("cookies.txt", MODE_PRIVATE).use { it.write(content.toByteArray(Charsets.UTF_8)) }
                true
            }
            runOnUiThread {
                if (result.isSuccess) toast("Cookie 已安全导入到本机") else toast("导入失败：${result.exceptionOrNull()?.message}")
                renderSettings()
            }
        }
    }

    private fun pasteLink() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        if (text.isBlank()) toast("剪贴板没有链接") else urlField?.setText(text.trim())
    }

    private fun card(): MaterialCardView = MaterialCardView(this).apply {
        radius = dp(18).toFloat()
        cardElevation = dp(1).toFloat()
        strokeWidth = dp(1)
        strokeColor = Color.rgb(232, 236, 243)
        setCardBackgroundColor(Color.WHITE)
        useCompatPadding = false
    }

    private fun text(value: String, size: Int, bold: Boolean, color: Int): TextView = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
        includeFontPadding = true
    }

    private fun margin(bottom: Int = 0, top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom); topMargin = dp(top) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun Int?.orZero(): Int = this ?: 0

    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        handler.removeCallbacks(refreshLoop)
        io.shutdown()
        super.onDestroy()
    }
}
