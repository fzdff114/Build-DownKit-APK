package com.downkit.android

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import androidx.core.content.FileProvider
import java.io.File

object MediaSaver {
    fun save(context: Context, source: File, folderUri: String = ""): Uri {
        require(source.exists() && source.isFile) { "下载文件不存在：${source.name}" }
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(source.extension.lowercase())
            ?: "application/octet-stream"

        if (folderUri.isNotBlank()) {
            val tree = DocumentFile.fromTreeUri(context, Uri.parse(folderUri))
                ?: throw IllegalStateException("保存目录不可用，请重新选择")
            val existing = tree.findFile(source.name)
            existing?.delete()
            val target = tree.createFile(mime, source.name)
                ?: throw IllegalStateException("无法在所选目录创建文件")
            context.contentResolver.openOutputStream(target.uri, "w").use { output ->
                requireNotNull(output) { "无法打开保存目标" }
                source.inputStream().use { input -> input.copyTo(output) }
            }
            return target.uri
        }

        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, source.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/DownKit")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("系统无法创建下载文件")
            try {
                resolver.openOutputStream(uri, "w").use { output ->
                    requireNotNull(output) { "无法打开系统下载目录" }
                    source.inputStream().use { input -> input.copyTo(output) }
                }
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                return uri
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
        }

        val targetDir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "DownKit").apply { mkdirs() }
        val target = File(targetDir, source.name)
        source.copyTo(target, overwrite = true)
        return FileProvider.getUriForFile(context, "${context.packageName}.files", target)
    }
}
