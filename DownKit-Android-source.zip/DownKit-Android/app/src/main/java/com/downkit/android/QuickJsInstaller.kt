package com.downkit.android

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File

object QuickJsInstaller {
    fun install(context: Context): String? {
        val abi = Build.SUPPORTED_ABIS.firstOrNull { it == "arm64-v8a" || it == "x86_64" } ?: return null
        return try {
            val dir = File(context.noBackupFilesDir, "runtime").apply { mkdirs() }
            val target = File(dir, "qjs")
            val expected = "quickjs/$abi/qjs"
            if (!target.exists() || target.length() < 100_000L) {
                context.assets.open(expected).use { input -> target.outputStream().use { output -> input.copyTo(output) } }
            }
            target.setReadable(true, true)
            target.setExecutable(true, true)
            target.setWritable(false, false)
            target.absolutePath
        } catch (e: Exception) {
            Log.e("DownKit", "QuickJS asset unavailable for $abi", e)
            null
        }
    }
}
