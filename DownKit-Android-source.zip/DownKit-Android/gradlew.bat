@echo off
setlocal
set "GRADLE_VERSION=8.13"
set "BASE_DIR=%USERPROFILE%\.gradle\downkit-bootstrap"
set "INSTALL_DIR=%BASE_DIR%\gradle-%GRADLE_VERSION%"
set "ZIP_FILE=%BASE_DIR%\gradle-%GRADLE_VERSION%-bin.zip"
set "TMP_FILE=%ZIP_FILE%.tmp"
if not exist "%INSTALL_DIR%\bin\gradle.bat" (
  if not exist "%BASE_DIR%" mkdir "%BASE_DIR%"
  if exist "%ZIP_FILE%" (
    powershell -NoProfile -Command "try { Add-Type -AssemblyName System.IO.Compression.FileSystem; $z=[System.IO.Compression.ZipFile]::OpenRead('%ZIP_FILE%'); $z.Dispose(); exit 0 } catch { exit 1 }"
    if errorlevel 1 del /q "%ZIP_FILE%"
  )
  if not exist "%ZIP_FILE%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%TMP_FILE%'"
    if errorlevel 1 exit /b 1
    powershell -NoProfile -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; $z=[System.IO.Compression.ZipFile]::OpenRead('%TMP_FILE%'); $z.Dispose()"
    if errorlevel 1 exit /b 1
    move /y "%TMP_FILE%" "%ZIP_FILE%" >nul
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%ZIP_FILE%' -DestinationPath '%BASE_DIR%' -Force"
  if errorlevel 1 exit /b 1
)
call "%INSTALL_DIR%\bin\gradle.bat" %*
endlocal
